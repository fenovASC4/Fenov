var pokeURL; //This will be the URL for Ajax to use
var pokeIndex; //This is the index of the current pokemon inside of the pokedex
var pokeName; //Stores the name of the current pokemon
var type1; // This will be the type, set equal to the type of the pokemon at the current pokeIndex
var type2; // Only used when a pokemon has more than one type
var multipleType; // Boolean switch to make the quiz act differently when a pokemon has more than one type
var questionsAnswered; // Incremented by one every time a question is answered
var score; // Incremented by one everytime a question is answered correctly
var gameOver; // Changes the look of the page to resemble a game over screen. Player reloads to restart

function makeURL(){ // This function makes the url
    pokeIndex = Math.floor((Math.random() * 152) + 1);
    pokeURL = "http://pokeapi.co/api/v2/pokemon/" + pokeIndex.toString();
}

makeURL();
console.log(pokeIndex);
console.log(pokeURL);

$.ajax({
    url: pokeURL,
    success: function(data){
        type1 = data.types[0].type.name;
        console.log(type1); // Logs the first type
        console.log(data.types.length); // Logs how many types the pokemon has
        /*if (data.types.length == 2){ // A conditional used to display the second type if there is one
            type2 = data.types[0].type.name;
            $("#" + type2).html("<button href='incrementScore();' class = 'typeButton' id = '" + type2 + "' >" + type2 + "</button>")
            $("#" + type1).html("<button href='incrementScore();' class = 'typeButton' id = '" + type1 + "' >" + type1 + "</button>")
        }
        else {

        }*/
        
        $("#Pokemon").append("<h1 class='center'>" + data.name + "</h1>")
        $("#answerType").append("<p class='center'>" + type1 + "</p>")

    }
})
